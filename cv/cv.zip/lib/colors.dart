import 'package:flutter/material.dart';

const Color primaryGreen = Color(0xFF61A081);
const Color lightGreenBg = Color(0xFFF1F6F3);
